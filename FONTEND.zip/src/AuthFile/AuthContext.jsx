import axios from 'axios';
import React, { createContext, useEffect, useState } from 'react'


export const AuthCon = createContext();



function AuthContext({ children}) {
    const [user, setUser] = useState(null);

    useEffect(() => {
         axios.get("https://localhost:7238/api/Auth/LoggedInUser", { withCredentials: true })
            .then((res) => { setUser(res.data)})
            .catch(() => { setUser(null) })
    },[])
    return (
        <AuthCon.Provider value={{user , setUser }}>
             {children}
        </AuthCon.Provider>
    )
}

export default AuthContext