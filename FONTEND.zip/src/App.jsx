import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './Home'
import Navbar from './Navbar'
import AddEmp from './AddEmp'
import EditEmp from './EditEmp'
import Sidebar from './Sidebar'
import Logs from './Logs'
import Register from './ServicesFile/Register'
import Login from './ServicesFile/Login'
import AuthContext from './AuthFile/AuthContext'
import Projects from './Pages/Projects'
import ReportPopup from './Popups/ReportPopup'
import AddEditProject from './AddPages.jsx/AddEditProject'
import Reports from './Pages/Reports'
import ReportViewPopup from './Popups/ReportViewPopUp'
import Manegment from './Pages/Manegment'
import Settings from './Pages/Settings'
// import DeletePopup from './Popups/DeletePopup'

function App() {

  return (
    <>
      <AuthContext>
        <BrowserRouter>
          <Navbar></Navbar>
          <Sidebar></Sidebar>
          <Routes>
            <Route path='/' element={<Home></Home>}>
              <Route path='register' element={<Register></Register>}></Route>
              <Route path='login' element={<Login></Login>}></Route>
              {/* <Route path='deletePopup' element={<DeletePopup></DeletePopup>}></Route> */}
              
            </Route>
            <Route path='/addEmployee' element={<AddEmp></AddEmp>}></Route>
            <Route path='/editEmployee/:id' element={<EditEmp></EditEmp>}></Route>
            <Route path='/logspage' element={<Logs></Logs>}></Route>
            <Route path="/Projects" element={<Projects></Projects>}>
               <Route path='report/:id' element={<ReportPopup></ReportPopup>}></Route>
               <Route path='addeditProject/:id' element={<AddEditProject></AddEditProject>}></Route>
               <Route path='addeditProject' element={<AddEditProject></AddEditProject>}></Route>
            </Route>
             <Route path='/reports' element={<Reports></Reports>}>
               <Route path='ReportViewPopup/:id' element={<ReportViewPopup></ReportViewPopup>}></Route>
             </Route>
             <Route path='/manegment' element={<Manegment></Manegment>}></Route>
             <Route path='/Settings' element={<Settings></Settings>}></Route>
          </Routes>
        </BrowserRouter>
      </AuthContext>
    </>
  )
}

export default App
