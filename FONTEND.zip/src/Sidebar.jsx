import React, { useContext, useState } from 'react';
import { NavLink } from 'react-router-dom';
import { AuthCon } from './AuthFile/AuthContext';

function Sidebar() {
    const { user } = useContext(AuthCon);
    const [newsOpen, setNewsOpen] = useState(false);

    return (
        <div className="sidebar">
            <ul className="nav flex-column">

                <NavLink to={"/"} className={({ isActive }) => `nav-item text-decoration-none ${isActive ? 'active' : ''}`}>Dashboard</NavLink>
                <NavLink to={"/manegment"} className={({ isActive }) => `nav-item text-decoration-none ${isActive ? 'active' : ''}`}>Management</NavLink>
                <NavLink to={"/Projects"} className={({ isActive }) => `nav-item text-decoration-none ${isActive ? 'active' : ''}`}>Projects</NavLink>
                <NavLink to={"/reports"} className={({ isActive }) => `nav-item text-decoration-none ${isActive ? 'active' : ''}`}>Reports</NavLink>
                {user?.role === "Admin" && (
                    <NavLink to={"/logspage"} className={({ isActive }) => `nav-item text-decoration-none ${isActive ? 'active' : ''}`}>Logs</NavLink>
                )}

                {/* News Dropdown */}
                <li className="nav-item dropdown ">
                    <div
                        className="nav-link d-flex justify-content-between align-items-center text-decoration-none p-0 fw-normal"
                        style={{ cursor: 'pointer' }}
                        onClick={() => setNewsOpen(!newsOpen)}
                    >
                        <span>News</span>
                        <i
                            className={`fa-solid fa-chevron-down text-white dropdown-arrow ${newsOpen ? 'open' : ''}`}
                        ></i>
                    </div>
                    {newsOpen && (
                        <ul className="dropdown-menu show mt-3">
                            <li>
                                <NavLink to="/news/latest" className="dropdown-item text-dark">Latest News</NavLink>
                            </li>
                            <li>
                                <NavLink to="/news/company" className="dropdown-item text-dark">Company News</NavLink>
                            </li>
                            <li>
                                <NavLink to="/news/industry" className="dropdown-item text-dark">Industry Updates</NavLink>
                            </li>
                        </ul>
                    )}
                </li>

                <NavLink to={"/Settings"} className={({ isActive }) => `nav-item text-decoration-none ${isActive ? 'active' : ''}`}>Settings</NavLink>

            </ul>
        </div>
    );
}

export default Sidebar;
