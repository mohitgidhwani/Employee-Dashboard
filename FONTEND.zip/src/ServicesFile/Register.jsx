import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../App.css';
import axios from 'axios';

function Register() {
  const [userData, setUserData] = useState({
    authName: "",
    authRole: "",
    passwordHash: "",
    country: "",
    age: "",
    gender: "",
    salary: "",
    joiningDate: "",
    ProfilePicture: ""
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    if (e.target.name === "ProfilePicture") {
      const file = e.target.files[0];

      if (file) {
        const reader = new FileReader();

        reader.onloadend = () => {
          setUserData({
            ...userData,
            ProfilePicture: reader.result, // Base64 string
          });
        };

        reader.readAsDataURL(file); // convert to Base64
      }
    } else {
      setUserData({ ...userData, [e.target.name]: e.target.value });
    }
  };




  const handleSubmit = () => { debugger;

    axios.post("https://localhost:7238/api/Auth/Register", userData , { withCredentials: true });
    console.log(userData)
    alert("Register Successfully!");
    navigate("/");
  };


  return (
    <div className="register-overlay d-flex justify-content-center align-items-center">
      <div className="register-modal p-4">

        <h2 className="register-title text-center mb-4">Register New User</h2>

        <div className="register-card p-4">
          <form>

            {/* Profile Image */}
            <div className="mb-3">
              <label className="form-label">Profile Image</label>
              <input
                type="file"
                className="form-control rounded-pill input-styled"
                name="ProfilePicture"
                accept="image/*"
                onChange={handleChange}
              />
            </div>

            <div className="row g-3">

              {/* User Name */}
              <div className="col-md-6">
                <label className="form-label">User Name</label>
                <input
                  type="text"
                  className="form-control rounded-pill input-styled"
                  placeholder="Enter your username"
                  name="authName"
                  value={userData.authName}
                  onChange={handleChange}
                />
              </div>

              {/* Role */}
              <div className="col-md-6">
                <label className="form-label">Role</label>
                <select
                  className="form-select rounded-pill input-styled"
                  name="authRole"
                  value={userData.authRole}
                  onChange={handleChange}
                >
                  <option value="">Select Role</option>
                  <option value="Admin">Admin</option>
                  <option value="Manager">Manager</option>
                  <option value="Employee">Employee</option>
                </select>
              </div>

              {/* Password */}
              <div className="col-md-6">
                <label className="form-label">Password</label>
                <input
                  type="password"
                  className="form-control rounded-pill input-styled"
                  placeholder="Enter your password"
                  name="passwordHash"
                  value={userData.passwordHash}
                  onChange={handleChange}
                />
              </div>

              {/* Country */}
              <div className="col-md-6">
                <label className="form-label">Country</label>
                <input
                  type="text"
                  className="form-control rounded-pill input-styled"
                  placeholder="Enter Country"
                  name="country"
                  value={userData.country}
                  onChange={handleChange}
                />
              </div>

              {/* Age */}
              <div className="col-md-6">
                <label className="form-label">Age</label>
                <input
                  type="number"
                  className="form-control rounded-pill input-styled"
                  placeholder="Enter Age"
                  name="age"
                  value={userData.age}
                  onChange={handleChange}
                />
              </div>

              {/* Gender */}
              <div className="col-md-6">
                <label className="form-label">Gender</label>
                <select
                  className="form-select rounded-pill input-styled"
                  name="gender"
                  value={userData.gender}
                  onChange={handleChange}
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              {/* Salary */}
              <div className="col-md-6">
                <label className="form-label">Salary</label>
                <input
                  type="number"
                  className="form-control rounded-pill input-styled"
                  placeholder="Enter Salary"
                  name="salary"
                  value={userData.salary}
                  onChange={handleChange}
                />
              </div>

              {/* Joining Date */}
              <div className="col-md-6">
                <label className="form-label">Joining Date</label>
                <input
                  type="date"
                  className="form-control rounded-pill input-styled"
                  name="joiningDate"
                  value={userData.joiningDate}
                  onChange={handleChange}
                />
              </div>

            </div>

            <div className="text-end mt-4">
              <Link to="/" className="btn btn-outline-secondary rounded-pill px-4 me-2">
                Cancel
              </Link>

              <button
                onClick={handleSubmit}
                type="button"
                className="btn btn-primary rounded-pill px-4"
              >
                Register
              </button>
            </div>

          </form>
        </div>

      </div>
    </div>
  );

}

export default Register;
