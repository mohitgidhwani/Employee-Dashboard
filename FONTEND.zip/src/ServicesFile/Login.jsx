import axios from 'axios'
import React, { useContext, useEffect, useState } from 'react'
import { Link, Outlet, useNavigate } from 'react-router-dom'
import { AuthCon } from '../AuthFile/AuthContext'
import Register from './Register'

function Login() {

    const [userData, setserData] = useState({
        authName: "",
        passwordHash: ""
    })

    const {user , setUser} = useContext(AuthCon);

    const navigate = useNavigate()

    const handleChange = (e) => {
        setserData({ ...userData, [e.target.name]: e.target.value })
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
       try{
         await axios.post("https://localhost:7238/api/Auth/Login",
            userData ,
            {withCredentials : true}
        )
       

        await axios.get("https://localhost:7238/api/Auth/LoggedInUser" ,  {withCredentials : true} , )
        .then((res)=>{setUser(res.data) , navigate("/")});
       }
     
       catch (error){
        // console.log('Login failed:', error.response.data)
        // alert('Login failed : ' + error.response.data)
       }
    }

    useEffect(()=>{

    },[user])

    return (
        <div className="register-overlay">
            <div className="register-modal">
                <h2 className="page-title mb-4 text-center text-primary">Login</h2>

                <div className="register-card shadow-sm bg-white rounded-4 p-4">
                    <form>
                        <div className="row g-4">
                            {/* Username */}
                            <div className="col-md-12">
                                <label className="form-label fw-semibold">User Name</label>
                                <input
                                    type="text"
                                    className="form-control rounded-pill"
                                    placeholder="Enter your username"
                                    name='authName'
                                    value={userData.authName}
                                    required
                                    onChange={handleChange}
                                />
                            </div>

                            {/* Password */}
                            <div className="col-md-12">
                                <label className="form-label fw-semibold">Password</label>
                                <input
                                    type="password"
                                    className="form-control rounded-pill"
                                    placeholder="Enter your password"
                                    name='passwordHash'
                                    required
                                    value={userData.passwordHash}
                                    onChange={handleChange}
                                />
                            </div>

                            {/* Buttons */}
                            <div className="col-12 text-end mt-4">
                                <Link
                                    to={"/"}
                                    type="button"
                                    className="btn btn-outline-secondary rounded-pill px-4 me-2"
                                >
                                    Cancel
                                </Link>
                                <button onClick={handleSubmit} type="button" className="btn btn-primary rounded-pill px-4">
                                    Login
                                </button>
                            </div>
                            <span>If Dont Have Account Create One <Link to={"/register"}>Register</Link></span>
                        </div>
                    </form>
                </div>
            </div>
            <Outlet></Outlet>
        </div>
    )
}

export default Login