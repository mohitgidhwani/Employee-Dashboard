import axios from "axios";
import React, { useContext, useEffect, useState } from "react";
import { AuthCon } from "../AuthFile/AuthContext";

function Manegment() {

  const [loggedIn, SetLOggedIn] = useState([])

  const { user, setUser } = useContext(AuthCon);

  useEffect(() => {
    axios.get("https://localhost:7238/api/Auth/GetAllRegisterUser", { withCredentials: true })
      .then((data) => { SetLOggedIn(data.data) })
      .catch((err) => { console.log("Error In getUserProfile" + err) })
  }, [])


  return (
    <div className="main-content">
      <h2 className="page-title">Management</h2>
      <div className="row g-4">
        {!user ? <div className="text-center fs-2 fw-bold py-4">Log In First</div> : loggedIn.map((value) => {
          if (value.authRole == "Admin") {
            return (
              <div className="col-md-4" key={value.id}>
                <div className="card shadow-sm text-center rounded-4 p-4 border-0">
                  <div className="d-flex justify-content-center">
                    <img
                      src={value.profilePicture}
                      alt="Profile"
                      className="profile-img"
                    />
                  </div>
                  <h5 className="mt-3 mb-1 fw-semibold">{value.authName}</h5>
                  <p className="text-muted mb-0">{value.authRole}</p>
                </div>
              </div>
            )
          }
        })}

      </div>
    </div>
  );
}

export default Manegment;
