import React, { useContext, useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { AuthCon } from '../AuthFile/AuthContext';

const Settings = () => {
    const { user, setUser } = useContext(AuthCon);
    const navigate = useNavigate();

    // Theme and color theme states
    const [theme, setTheme] = useState(localStorage.getItem("theme") || "light");
    const [colorTheme, setColorTheme] = useState(localStorage.getItem("colorTheme") || "blue");
    const [loggedIn, setLoggedIn] = useState([]);
    const [showColorDropdown, setShowColorDropdown] = useState(false);

    // Apply theme to the <html> tag
    useEffect(() => {
        document.documentElement.setAttribute("data-theme", theme);
        document.documentElement.setAttribute("data-color-theme", colorTheme);
        localStorage.setItem("theme", theme);
        localStorage.setItem("colorTheme", colorTheme);
    }, [theme, colorTheme]);

    // Fetch user data
    useEffect(() => {
        axios.get("https://localhost:7238/api/Auth/GetAllRegisterUser", { withCredentials: true })
            .then((res) => setLoggedIn(res.data))
            .catch((err) => console.error("Error fetching user profile:", err));
    }, []);

    // Theme toggle function
    const handleThemeToggle = () => {
        setTheme((prev) => (prev === "light" ? "dark" : "light"));
    };

    // Color theme change function
    const handleColorThemeChange = (color) => {
        setColorTheme(color);
        setShowColorDropdown(false); // Close dropdown after selection
    };

    // Logout function
    const handleLogout = () => {
        axios.post("https://localhost:7238/api/Auth/Logout", {}, { withCredentials: true })
            .then(() => {
                setUser(null);
                navigate("/");
            })
            .catch((err) => console.error("Logout failed:", err));
    };

    // Get theme display name and color
    const getThemeInfo = () => {
        const themes = {
            blue: { name: "Blue", color: "#2a49ff" },
            purple: { name: "Purple", color: "#8b5cf6" },
            green: { name: "Green", color: "#10b981" },
            red: { name: "Red", color: "#ef4444" },
            orange: { name: "Orange", color: "#f97316" },
            pink: { name: "Pink", color: "#ec4899" }
        };
        return themes[colorTheme] || themes.blue;
    };

    const currentTheme = getThemeInfo();

    return (
        <div className="main-content">
            <h1 className="mb-4 text-primary">Settings</h1>

            <div className="row g-4">
                {/* Left Panel - User Identity Card */}
                {user && loggedIn.map((data) => (
                    data.authName === user.name && data.authRole === user.role && (
                        <div className="col-md-4" key={data.id}>
                            <div className="card shadow-sm p-4 rounded-4 text-center h-100 d-flex flex-column justify-content-center">
                                <img
                                    src={data.profilePicture}
                                    alt="Profile"
                                    className="profile-img mb-3 d-block m-auto setting-profile-img"
                                />
                                <h5 className="fw-semibold mb-1">{user.name}</h5>
                                <p className="text-secondary mb-3">{user.role}</p>

                                <button
                                    className="btn btn-outline-danger rounded-pill w-100"
                                    onClick={handleLogout}
                                >
                                    Logout
                                </button>
                            </div>
                        </div>
                    )
                ))}

                {/* Right Panel - Account Settings & Preferences */}
                {loggedIn.map((data) => (
                    data.authName === user?.name && data.authRole === user?.role && (
                        <div className={user ? "col-md-8" : "col-md-12"} key={`settings-${data.id}`}>
                            <div className="card shadow-sm p-4 rounded-4">
                                <h5 className="mb-3 fw-semibold text-primary">Account</h5>

                                <div className="mb-3">
                                    <label className="form-label">Role</label>
                                    <h4 className="text-primary">{user.role}</h4>
                                </div>

                                <div className="mb-3">
                                    <label className="form-label">Username</label>
                                    <input
                                        type="text"
                                        className="form-control rounded-pill"
                                        defaultValue={user?.name}
                                    />
                                </div>

                                <div className="mb-3">
                                    <label className="form-label">Email</label>
                                    <input
                                        type="email"
                                        disabled
                                        className="form-control rounded-pill opacity-75"
                                        placeholder="user@example.com"
                                    />
                                </div>

                                <h5 className="mb-3 fw-semibold text-primary mt-4">Preferences</h5>

                                <div className="form-check form-switch mb-2">
                                    <input className="form-check-input" type="checkbox" id="notifications" />
                                    <label className="form-check-label" htmlFor="notifications">
                                        Enable Notifications
                                    </label>
                                </div>

                                <div className="form-check form-switch mb-2">
                                    <input
                                        className="form-check-input"
                                        type="checkbox"
                                        id="darkmode"
                                        checked={theme === "dark"}
                                        onChange={handleThemeToggle}
                                    />
                                    <label className="form-check-label" htmlFor="darkmode">
                                        Dark Mode
                                    </label>
                                </div>

                                {/* COLOR THEME DROPDOWN */}
                                <div className="mb-3 mt-3">
                                    <label className="form-label fw-semibold mb-2">Theme Color</label>
                                    <div className="dropdown">
                                        <button
                                            className="btn btn-outline-secondary dropdown-toggle w-100 rounded-pill d-flex align-items-center justify-content-between"
                                            type="button"
                                            onClick={() => setShowColorDropdown(!showColorDropdown)}
                                            aria-expanded={showColorDropdown}
                                        >
                                            <div className="d-flex align-items-center gap-2">
                                                <div 
                                                    className="rounded-circle"
                                                    style={{
                                                        width: '20px',
                                                        height: '20px',
                                                        backgroundColor: currentTheme.color,
                                                        border: '2px solid #fff',
                                                        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                                                    }}
                                                ></div>
                                                <span>{currentTheme.name}</span>
                                            </div>
                                        </button>
                                        
                                        {showColorDropdown && (
                                            <div className="dropdown-menu show w-100 rounded-3 p-2" style={{ display: 'block' }}>
                                                <div className="d-flex flex-column gap-2">
                                                    {/* Blue Theme */}
                                                    <button 
                                                        className={`dropdown-item d-flex align-items-center gap-3 p-2 rounded-2 ${colorTheme === 'blue' ? 'bg-primary text-white' : ''}`}
                                                        onClick={() => handleColorThemeChange('blue')}
                                                    >
                                                        <div 
                                                            className="rounded-circle"
                                                            style={{
                                                                width: '20px',
                                                                height: '20px',
                                                                backgroundColor: '#2a49ff'
                                                            }}
                                                        ></div>
                                                        <span>Blue</span>
                                                    </button>
                                                    
                                                    {/* Purple Theme */}
                                                    <button 
                                                        className={`dropdown-item d-flex align-items-center gap-3 p-2 rounded-2 ${colorTheme === 'purple' ? 'bg-primary text-white' : ''}`}
                                                        onClick={() => handleColorThemeChange('purple')}
                                                    >
                                                        <div 
                                                            className="rounded-circle"
                                                            style={{
                                                                width: '20px',
                                                                height: '20px',
                                                                backgroundColor: '#8b5cf6'
                                                            }}
                                                        ></div>
                                                        <span>Purple</span>
                                                    </button>
                                                    
                                                    {/* Green Theme */}
                                                    <button 
                                                        className={`dropdown-item d-flex align-items-center gap-3 p-2 rounded-2 ${colorTheme === 'green' ? 'bg-primary text-white' : ''}`}
                                                        onClick={() => handleColorThemeChange('green')}
                                                    >
                                                        <div 
                                                            className="rounded-circle"
                                                            style={{
                                                                width: '20px',
                                                                height: '20px',
                                                                backgroundColor: '#10b981'
                                                            }}
                                                        ></div>
                                                        <span>Green</span>
                                                    </button>
                                                    
                                                    {/* Red Theme */}
                                                    <button 
                                                        className={`dropdown-item d-flex align-items-center gap-3 p-2 rounded-2 ${colorTheme === 'red' ? 'bg-primary text-white' : ''}`}
                                                        onClick={() => handleColorThemeChange('red')}
                                                    >
                                                        <div 
                                                            className="rounded-circle"
                                                            style={{
                                                                width: '20px',
                                                                height: '20px',
                                                                backgroundColor: '#ef4444'
                                                            }}
                                                        ></div>
                                                        <span>Red</span>
                                                    </button>
                                                    
                                                    {/* Orange Theme */}
                                                    <button 
                                                        className={`dropdown-item d-flex align-items-center gap-3 p-2 rounded-2 ${colorTheme === 'orange' ? 'bg-primary text-white' : ''}`}
                                                        onClick={() => handleColorThemeChange('orange')}
                                                    >
                                                        <div 
                                                            className="rounded-circle"
                                                            style={{
                                                                width: '20px',
                                                                height: '20px',
                                                                backgroundColor: '#f97316'
                                                            }}
                                                        ></div>
                                                        <span>Orange</span>
                                                    </button>
                                                    
                                                    {/* Pink Theme */}
                                                    <button 
                                                        className={`dropdown-item d-flex align-items-center gap-3 p-2 rounded-2 ${colorTheme === 'pink' ? 'bg-primary text-white' : ''}`}
                                                        onClick={() => handleColorThemeChange('pink')}
                                                    >
                                                        <div 
                                                            className="rounded-circle"
                                                            style={{
                                                                width: '20px',
                                                                height: '20px',
                                                                backgroundColor: '#ec4899'
                                                            }}
                                                        ></div>
                                                        <span>Pink</span>
                                                    </button>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                </div>

                                <div className="text-end mt-4">
                                    <button className="btn btn-primary rounded-pill px-5">
                                        Save Changes
                                    </button>
                                </div>
                            </div>
                        </div>
                    )
                ))}
            </div>
        </div>
    );
};

export default Settings;