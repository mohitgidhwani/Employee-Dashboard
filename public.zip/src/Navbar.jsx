import React, { useContext, useEffect, useState } from 'react';
import './App.css';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { AuthCon } from './AuthFile/AuthContext';

function Navbar() {


  const {user , setUser} = useContext(AuthCon);


  const handleLogout = () => {
     axios.post("https://localhost:7238/api/Auth/Logout", {}, { withCredentials: true })
    .then(() => {
      setUser(null);
     
    })
    .catch((err) => console.error("Logout failed:", err));
}


return (
  <nav className="navbar navbar-expand-lg custom-navbar shadow-sm">
    <div className="container-fluid">
      {/* Brand / Logo */}
      <a className="navbar-brand fw-bold text-white fs-4" href="#">
        EMS
      </a>

      {/* Mobile Toggle */}
      <button
        className="navbar-toggler text-white"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span className="navbar-toggler-icon"></span>
      </button>

      {/* Navbar Links */}
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav ms-auto align-items-center">

          {/* Search Box */}
          <form className="d-flex ms-3 me-4" role="search">
            <input
              className="form-control search-input rounded-pill"
              type="search"
              placeholder="Search..."
              aria-label="Search"
            />
          </form>

          {/* Register Button */}
          <li className="nav-item">


            {!user ? (<>
              <Link
                to={"register"}
                className="btn btn-outline-light rounded-pill px-4 py-2 fw-semibold me-3 register-btn"
              >
                Register
              </Link>
              <Link
                to={"login"}
                className="btn btn-outline-light rounded-pill px-4 py-2 fw-semibold me-3 register-btn"
              >
                Login
              </Link>
            </>
            ) : <button onClick={handleLogout} className='btn btn-outline-light rounded-pill px-4 py-2 fw-semibold me-3 register-btn'>Logout</button>}

          </li>

          {/* Profile Section */}
          {!user ? "" : <li className="nav-item d-flex align-items-center">
            <div className="me-2 text-white text-end">
              <div className="fw-semibold">{user.name}</div>
              <small className="text-light"> {user.role}</small>
            </div>
            <img
              src="https://upload.wikimedia.org/wikipedia/commons/9/99/Sample_User_Icon.png"
              alt="profile"
              className="rounded-circle border border-light profile-pic"
            />
          </li>}
        </ul>
      </div>
    </div>
  </nav>
);
}

export default Navbar;
