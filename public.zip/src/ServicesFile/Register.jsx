import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import '../App.css'
import axios from 'axios'

function Register() {

  const [userData, setserData] = useState({
    authName: "",
    authRole: "",
    passwordHash: ""
  })

  const navigate = useNavigate()

  const handleChange = (e) => {
    setserData({ ...userData, [e.target.name]: e.target.value })
  }


  const handleSubmit = () => {
    axios.post("https://localhost:7238/api/Auth/Register",
      userData
    )
    alert("Register Successfully.....!")

    navigate("/")
  }

  return (
    <div className="register-overlay">
      <div className="register-modal">
        <h2 className="page-title mb-4 text-center text-primary">Register New User</h2>

        <div className="register-card shadow-sm bg-white rounded-4 p-4">
          <form>
            <div className="row g-4">
              {/* Username */}
              <div className="col-md-12">
                <label className="form-label fw-semibold">User Name</label>
                <input
                  type="text"
                  className="form-control rounded-pill"
                  placeholder="Enter your username"
                  name='authName'
                  value={userData.authName}
                  onChange={handleChange}
                />
              </div>

              {/* Role */}
              <div className="col-md-12">
                <label className="form-label fw-semibold">Role</label>
                <select className="form-select rounded-pill" value={userData.authRole} onChange={handleChange} name='authRole'>
                  <option value="">Select Role</option>
                  <option value="Admin">Admin</option>
                  <option value="Manager">Manager</option>
                  <option value="Employee">Employee</option>
                </select>
              </div>

              {/* Password */}
              <div className="col-md-12">
                <label className="form-label fw-semibold">Password</label>
                <input
                  type="password"
                  className="form-control rounded-pill"
                  placeholder="Enter your password"
                  name='passwordHash'
                  value={userData.passwordHash}
                  onChange={handleChange}
                />
              </div>

              {/* Buttons */}
              <div className="col-12 text-end mt-4">
                <Link
                  to={"/"}
                  type="button"
                  className="btn btn-outline-secondary rounded-pill px-4 me-2"
                >
                  Cancel
                </Link>
                <button onClick={handleSubmit} type="button" className="btn btn-primary rounded-pill px-4">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}

export default Register
