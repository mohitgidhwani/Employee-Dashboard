import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './Home'
import Navbar from './Navbar'
import AddEmp from './AddEmp'
import EditEmp from './EditEmp'
import Sidebar from './Sidebar'
import Logs from './Logs'
import Register from './ServicesFile/Register'
import Login from './ServicesFile/Login'
import AuthContext from './AuthFile/AuthContext'

function App() {

  return (
    <>
      <AuthContext>
        <BrowserRouter>
          <Navbar></Navbar>
          <Sidebar></Sidebar>
          <Routes>
            <Route path='/' element={<Home></Home>}>
              <Route path='register' element={<Register></Register>}></Route>
              <Route path='login' element={<Login></Login>}></Route>
            </Route>
            <Route path='/addEmployee' element={<AddEmp></AddEmp>}></Route>
            <Route path='/editEmployee/:id' element={<EditEmp></EditEmp>}></Route>
            <Route path='/logspage' element={<Logs></Logs>}></Route>
          </Routes>
        </BrowserRouter>
      </AuthContext>



    </>
  )
}

export default App
