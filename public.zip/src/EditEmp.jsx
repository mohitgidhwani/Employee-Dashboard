import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

function EditEmp() {

    const [empData, setEmpData] = useState({
        empName: "",
        empAge: 0,
        empGender: "",
        empSalary: 0,
        empCountry: ""
    })


    const { id } = useParams()

    useEffect(() => {
        axios.get(`https://localhost:7238/api/Employee/${id}` , {withCredentials : true})
            .then((data) => { setEmpData(data.data) })
    }, [])

    const navigate = useNavigate()

    const handleChange = (e) => {
        e.preventDefault()

        setEmpData({ ...empData, [e.target.name]: e.target.value });
    }

    const handleSubmit = async (e) => {

        await axios.patch(`https://localhost:7238/api/Employee/${id}`,
            empData ,
            {withCredentials : true}
        )

        await navigate("/")
    }

    return (
        <div className="main-content">
            <h2 className="page-title mb-4">Edit Employee</h2>

            <div className="form-card shadow-sm bg-white rounded-4 p-4">
                <form>
                    <div className="row g-4">
                        {/* Employee Name */}
                        <div className="col-md-6">
                            <label className="form-label fw-semibold">Employee Name</label>
                            <input
                                type="text"
                                className="form-control rounded-pill"
                                placeholder="Enter employee name"
                                name='empName'
                                value={empData.empName}
                                onChange={handleChange}
                            />
                        </div>

                        {/* Country */}
                        <div className="col-md-6">
                            <label className="form-label fw-semibold">Country</label>
                            <select className="form-select rounded-pill" name='empCountry' value={empData.empCountry} onChange={handleChange}>
                                <option value="">Select country</option>
                                <option value="India">India</option>
                                <option value="USA">USA</option>
                                <option value="Australia">Australia</option>
                                <option value="UK">UK</option>
                            </select>
                        </div>

                        {/* Age */}
                        <div className="col-md-6">
                            <label className="form-label fw-semibold">Age</label>
                            <input
                                type="number"
                                className="form-control rounded-pill"
                                placeholder="Enter age"
                                name='empAge'
                                value={empData.empAge}
                                onChange={handleChange}
                            />
                        </div>

                        {/* Gender */}
                        <div className="col-md-6">
                            <label className="form-label fw-semibold">Gender</label>
                            <select className="form-select rounded-pill" name='empGender' value={empData.empGender} onChange={handleChange}>
                                <option value="">Select gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        {/* Salary */}
                        <div className="col-md-12">
                            <label className="form-label fw-semibold">Salary</label>
                            <input
                                type="text"
                                className="form-control rounded-pill"
                                placeholder="Enter salary amount"
                                name='empSalary'
                                value={empData.empSalary}
                                onChange={handleChange}
                            />
                        </div>

                        {/* Buttons */}
                        <div className="col-12 text-end mt-4">
                            <button type="button" onClick={()=>{navigate("/")}} className="btn btn-outline-secondary rounded-pill px-4 me-2">
                                Cancel
                            </button>
                            <button onClick={handleSubmit} type="button" className="btn btn-primary rounded-pill px-4">
                                Save Changes
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    )
}

export default EditEmp