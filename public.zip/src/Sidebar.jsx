import React from 'react'
import { Link, NavLink } from 'react-router-dom'

function Sidebar() {
    return (
        <div className="sidebar">
            <ul className="nav flex-column">
                <NavLink to={"/"} className={({isActive}) => `nav-item text-decoration-none ${isActive ? 'active' : ''}` } >Dashboard</NavLink>
                <NavLink to={"/Employees"}  className={({isActive}) => `nav-item text-decoration-none ${isActive ? 'active' : ''}` }>Employees</NavLink>
                <NavLink to={"/Orders"}  className={({isActive}) => `nav-item text-decoration-none ${isActive ? 'active' : ''}` }>Orders</NavLink>
                <NavLink  to={"/Reports"} className={({isActive}) => `nav-item text-decoration-none ${isActive ? 'active' : ''}` }>Reports</NavLink>
                <NavLink to={"/logspage"}  className={({isActive}) => `nav-item text-decoration-none ${isActive ? 'active' : ''}` }>Logs</NavLink>
                <NavLink to={"/Settings"}  className={({isActive}) => `nav-item text-decoration-none ${isActive ? 'active' : ''}` }>Settings</NavLink>
            </ul>
        </div>
    )
}

export default Sidebar