﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace employeeDashboard.Models;

public partial class Project
{
    [Key]
    public int ProjectId { get; set; }

    [StringLength(200)]
    public string? ProjectName { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? ProjectDate { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string? ClientName { get; set; }

    [StringLength(150)]
    [Unicode(false)]
    public string? ClientLocation { get; set; }

    [StringLength(100)]
    public string? Duration { get; set; }

    [Column(TypeName = "decimal(18, 0)")]
    public decimal? Ammount { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string? ProjectCategory { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? DeadLine { get; set; }

    [InverseProperty("Project")]
    public virtual ICollection<ReportDetail> ReportDetails { get; set; } = new List<ReportDetail>();
}
