﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace employeeDashboard.Models;

public partial class ReportDetail
{
    [Key]
    public int ReportId { get; set; }


    public string? Report { get; set; }

    public string? ReportStatus { get; set; }

    public string? IssueDetails { get; set; }

    public string? Priority { get; set; }

    public int? ProjectId { get; set; }

    public string? Name { get; set; }

    public DateOnly? ReportDate { get; set; }

    public string? ProjectName { get; set; }

    [System.Text.Json.Serialization.JsonIgnore]
    public virtual Project? Project { get; set; }
}
