﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace employeeDashboard.Models;

[Table("EmploayeeAuth")]
public partial class EmploayeeAuth
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string? AuthName { get; set; }

    [StringLength(50)]
    [Unicode(false)]
    public string? AuthRole { get; set; }

    [Unicode(false)]
    public string? PasswordHash { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string? Country { get; set; }

    public int? Age { get; set; }

    [StringLength(100)]
    [Unicode(false)]
    public string? Gender { get; set; }

    [Column(TypeName = "decimal(18, 0)")]
    public decimal? Salary { get; set; }

    public DateOnly? JoiningDate { get; set; }

    public string? ProfilePicture { get; set; }
}
