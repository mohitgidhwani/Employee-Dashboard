﻿using employeeDashboard.Models;

namespace employeeDashboard.Repositories
{
    public interface IAuthRepository
    {
        Task<bool> RegisterAsync(EmploayeeAuth user);
        Task<EmploayeeAuth?> LoginAsync(EmploayeeAuth user);
    }
}
