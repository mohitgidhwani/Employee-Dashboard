﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace employeeDashboard.Models;

public partial class EmployeeManagementContext : DbContext
{
    public EmployeeManagementContext()
    {
    }

    public EmployeeManagementContext(DbContextOptions<EmployeeManagementContext> options)
        : base(options)
    {
    }

    public virtual DbSet<EmploayeeAuth> EmploayeeAuths { get; set; }

    public virtual DbSet<EmployeeDatum> EmployeeData { get; set; }

    public virtual DbSet<EmployeeLog> EmployeeLogs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    { }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<EmploayeeAuth>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Emploaye__3213E83F652C90C9");

            entity.ToTable("EmploayeeAuth");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.AuthName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.AuthRole)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.PasswordHash).IsUnicode(false);
        });

        modelBuilder.Entity<EmployeeDatum>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Employee__3213E83FEE77B62F");

            entity.ToTable(tb => tb.HasTrigger("trg_EmployeeLogs"));

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.EmpCountry)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.EmpGender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.EmpName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.EmpSalary).HasColumnType("decimal(18, 0)");
        });

        modelBuilder.Entity<EmployeeLog>(entity =>
        {
            entity.HasKey(e => e.LogId).HasName("PK__Employee__7839F64DB41E88DB");

            entity.Property(e => e.LogId).HasColumnName("logId");
            entity.Property(e => e.ActionType)
                .HasMaxLength(10)
                .IsUnicode(false);
            entity.Property(e => e.ChangeDate)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.EmpCountry)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.EmpGender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.EmpName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.EmpSalary).HasColumnType("decimal(18, 0)");
            entity.Property(e => e.Id).HasColumnName("id");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
