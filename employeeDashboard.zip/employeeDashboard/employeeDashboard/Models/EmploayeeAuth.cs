﻿using System;
using System.Collections.Generic;

namespace employeeDashboard.Models;

public partial class EmploayeeAuth
{
    public int Id { get; set; }

    public string? AuthName { get; set; }

    public string? AuthRole { get; set; }

    public string? PasswordHash { get; set; }
}
