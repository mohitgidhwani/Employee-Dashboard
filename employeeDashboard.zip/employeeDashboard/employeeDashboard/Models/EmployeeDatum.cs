﻿using System;
using System.Collections.Generic;

namespace employeeDashboard.Models;

public partial class EmployeeDatum
{
    public int Id { get; set; }

    public string? EmpName { get; set; }

    public int? EmpAge { get; set; }

    public string? EmpGender { get; set; }

    public decimal? EmpSalary { get; set; }

    public string? EmpCountry { get; set; }
}
